SOFA ARCADE — LOCAL PLAY

One Mac, one TV, two phones. Keep the devices on the same home Wi-Fi.

1. Install Node.js 22.13 or newer if needed: https://nodejs.org/
2. Open start-sofa.command, or open Terminal in this folder and run:

   bash start-sofa.command

3. Open the local address printed in Terminal on your Mac.
4. Choose Sofa Kingdoms, then Host on the TV.
5. Scan the room QR with both phones. Cast the Mac browser to your TV.

Keep Terminal open while playing. Press Control+C to stop.
No npm install, build, account, or internet connection is needed during play.

If you prefer to start it directly:
   node scripts/lan-server.mjs

Room state is saved beside these files in .sofa-lan/rooms.sqlite.
Local rooms are separate from the public website's rooms and last 24 hours.
See docs/LAN.md for connection help and technical details.

Artwork and music were created for Jon, Lydia, and Lala.
The QR-code library's MIT license is in public/assets/qrcode-LICENSE.txt.
