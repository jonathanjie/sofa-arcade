import {svgIcon,fallbackBuilding,fallbackCharacter,mediaPicture} from './graphics.mjs';
export const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const icon=svgIcon;
export const NAMES=Object.freeze({jon:'Jon',lydia:'Lydia',lala:'Lala'});
export const buildingById=(rules,id)=>rules.buildings.find(item=>item.id===id);
export const lawName=(id,rules)=>id==='keep'?'Keep current law':rules.laws.find(item=>item.id===id)?.name || (id==='economy-neutral'?'Open city':'Quiet council');
export const lawDescription=(id,rules)=>rules.laws.find(item=>item.id===id)?.description || (id==='economy-neutral'?'No construction or Work modifier.':id==='civic-neutral'?'No Civic prestige at session end.':'Keep the current law in this category.');
export const scoreCurrent=p=>['buildings','streets','festivals','civic'].reduce((n,k)=>n+(Number(p?.score?.[k])||0),0);
export function guildLabel(id,rules) {const g=rules.guilds.find(x=>x.id===id);return `<span class="ols-guild ols-guild-${escapeHtml(id)}" data-guild="${escapeHtml(id)}">${icon(g?.iconKey||id)}<span>${escapeHtml(g?.name||id)}</span></span>`;}
export function buildingArt(design, ctx, {fullSize = false, lazy = false} = {}) {
  const entry = ctx.media?.manifest?.buildings?.[design?.id];
  const sizes = fullSize ? undefined : '(max-width: 760px) 75px, 115px';
  return mediaPicture(entry, fallbackBuilding(design), ctx.media?.manifestUrl, 'ols-building-art', '', {sizes, lazy});
}
export function character(id, state, ctx, sizes) {
  const entry = ctx.media?.manifest?.characters?.[id]?.states?.[state];
  const portrait = mediaPicture(entry, fallbackCharacter(id, state), ctx.media?.manifestUrl, '', NAMES[id] || id, {sizes});
  return `<span class="ols-character ols-character-${escapeHtml(id)}" data-character="${escapeHtml(id)}" data-character-state="${escapeHtml(state)}">${portrait}</span>`;
}
export function resourceStrip(player) {return `<div class="ols-resources" aria-label="Resources"><span class="ols-resource ols-coins" data-resource="coins">${icon('coin')}<strong class="ols-resource-value">${player.coins}</strong><span class="ols-resource-label">coins</span></span><span class="ols-resource ols-influence" data-resource="influence">${icon('influence')}<strong class="ols-resource-value">${player.influence}</strong><span class="ols-resource-label">influence</span></span><span class="ols-resource ols-prestige" data-resource="prestige">${icon('prestige')}<strong class="ols-resource-value">${scoreCurrent(player)}</strong><span class="ols-resource-label">prestige</span></span></div>`;}
export function cityGrid(view,playerId,ctx,{interactive=false}={}) {
 const city=view.players[playerId].city;
 return `<div class="ols-city-grid" data-player-id="${playerId}" aria-label="${NAMES[playerId]}'s city">${[0,1,2].map(row=>`<div class="ols-street" data-player-id="${playerId}" data-street="${row}">${[0,1,2].map(col=>{const entry=city[row*3+col],d=entry&&buildingById(ctx.rules,entry.designId); const label=`Street ${row+1}, plot ${col+1}${d?`: ${d.name}, ${ctx.rules.guilds.find(g=>g.id===d.guild)?.name||d.guild} guild`:', empty plot'}`;return `<button type="button" class="ols-plot${entry?' ols-plot-built':' ols-plot-empty'}${d?` ols-plot-${d.guild}`:''}" data-player-id="${playerId}" data-street="${row}" data-row="${row}" data-col="${col}"${entry?` data-guild="${escapeHtml(d?.guild||'')}" data-instance-id="${escapeHtml(entry.instanceId)}" data-design-id="${escapeHtml(entry.designId)}" data-action="inspect-building"`:interactive?' data-action="phone-plot"':' tabindex="-1" aria-disabled="true"'} aria-label="${escapeHtml(label)}">${d?`${buildingArt(d,ctx)}<span class="ols-plot-label">${escapeHtml(d.name)}</span><span class="ols-plot-guild">${icon(d.guild)}</span>`:`<span class="ols-plot-number">${row+1}${String.fromCharCode(65+col)}</span><span class="ols-plot-plus" aria-hidden="true">+</span>`}</button>`;}).join('')}</div>`).join('')}</div>`;
}
export function scoreTable(view) {return `<table class="ols-score-table"><caption>Prestige breakdown${view.stage==='finished'?'':' · treasury is potential'}</caption><thead><tr><th scope="col">Source</th><th scope="col">Jon</th><th scope="col">Lydia</th></tr></thead><tbody>${[['buildings','Buildings'],['streets','Streets'],['festivals','Festivals'],['civic','Civic laws'],['treasury',view.stage==='finished'?'Treasury':'Potential treasury']].map(([key,name])=>`<tr><th scope="row">${name}</th><td>${view.players.jon.score[key]}</td><td>${view.players.lydia.score[key]}</td></tr>`).join('')}<tr class="ols-score-total"><th scope="row">${view.stage==='finished'?'Final prestige':'Including potential treasury'}</th><td>${view.players.jon.score.total}</td><td>${view.players.lydia.score.total}</td></tr></tbody></table>`;}
